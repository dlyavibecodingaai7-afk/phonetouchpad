# Phone Touchpad

Смартфон Android — сенсорная панель для курсора Windows в одной Wi‑Fi сети.
Поиск автоматический (UDP broadcast). Команды — отдельные UDP-пакеты, без TCP.

| | |
|---|---|
| Обнаружение | UDP `50506`. Телефон шлёт `FIND_PC`, ПК отвечает `PC:<имя>` |
| Команды | UDP `50505`. `M dx dy`, `C left\|right\|middle down\|up`, `T left\|right`, `S dy dx` |
| Windows | Python 3.11+, `windows/mouse_host.py` → один `.exe` |
| Android | `com.example.phonetouchpad`, minSdk 26, compile/target 36 |

Протокол портов и текстов команд не менялся.

Надёжность, не протокол:

- Телефон кроме `255.255.255.255` шлёт `FIND_PC` на broadcast подсети. На Android 10+ пакет на `255.255.255.255` часто не выходит с Wi‑Fi.
- Сокеты телефона привязываются к интерфейсу Wi‑Fi (`Network.bindSocket`), чтобы VPN и LTE их не забрали.
- Добавлены `ACCESS_NETWORK_STATE` и `ACCESS_WIFI_STATE` — без них нельзя выбрать Wi‑Fi и посчитать broadcast. `INTERNET` и `CHANGE_WIFI_MULTICAST_STATE` на месте.
- Дробный остаток чувствительности 1.6 копится, чтобы медленное движение не пропадало. В сеть уходят те же целые `M dx dy`.
- Пока тачпад на экране, дисплей не гаснет. Уход из приложения отпускает зажатую левую кнопку.

## Сборка Windows (.exe)

На Windows 10 Pro x64, в каталоге `windows`:

```bat
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python test_protocol.py
python mouse_host.py
pyinstaller --onefile --noconsole --name PhoneTouchpad mouse_host.py
```

Готовый файл: `dist\PhoneTouchpad.exe`. Запуск двойным щелчком, иконка в трее, пункт «Выход».

Если иконки в собранном exe нет (PyInstaller не увидел backend):

```bat
pyinstaller --onefile --noconsole --name PhoneTouchpad --hidden-import=pystray._win32 --collect-submodules pystray mouse_host.py
```

Без установленных `pystray` и `pillow` скрипт работает без трея: процесс нужно завершать в диспетчере задач. Для exe трей лучше не пропускать.

Лог: `%TEMP%\phonetouchpad.log`.

## Сборка Android (.apk)

Нужны Android Studio с Android SDK 36 и JDK 17. Открыть каталог `android`, дождаться Gradle Sync.

Либо из `android`:

```bat
gradlew.bat assembleDebug
```

На macOS/Linux:

```sh
chmod +x ./gradlew
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

Установка:

```bat
adb install -r app\build\outputs\apk\debug\app-debug.apk
```

Телефон и ПК в одной обычной (не гостевой) сети Wi‑Fi. На Windows при первом запуске разрешить доступ в частных сетях.

## Жесты

- Один палец — движение курсора, чувствительность 1.6. Пакет уходит, когда накопленный сдвиг больше 0.5.
- Короткий тап короче 200 мс и короче 12 px — `T left`.
- Тап двумя пальцами — `T right`.
- Два пальца едут — прокрутка `S`. 8 px = один шаг, шаг × 40. Вертикаль инвертирована (`-sy`).
- Второй тап в течение 300 мс и не дальше 80 px, затем удержание — перетаскивание: `C left down` сразу, `C left up` при отпускании. Первый короткий тап при этом уже отправил `T left` (иначе каждый клик ждал бы 300 мс).

Кнопка «Найти компьютеры» и системная «Назад» с тачпада возвращают к списку.
