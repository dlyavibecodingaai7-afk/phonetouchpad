#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phone Touchpad — приёмник на Windows.

UDP 50506  discovery:  FIND_PC  ->  PC:<hostname>
UDP 50505  команды:    M / C / T / S

Запуск: python mouse_host.py
Сборка: pyinstaller --onefile --noconsole --name PhoneTouchpad mouse_host.py

Права администратора не нужны. Если Windows Firewall молча отбрасывает
входящий UDP, откройте порты 50505 и 50506 для частных сетей.
Лог: %TEMP%\\phonetouchpad.log
"""

from __future__ import annotations

import os
import socket
import sys
import tempfile
import threading
import time

DISCOVERY_PORT = 50506
COMMAND_PORT = 50505
DISCOVERY_TOKEN = b"FIND_PC"

stop_event = threading.Event()
_sockets_lock = threading.Lock()
_sockets: list[socket.socket] = []


def log(message: str) -> None:
    line = time.strftime("%Y-%m-%d %H:%M:%S ") + message
    if sys.stderr is not None:
        try:
            print(line, file=sys.stderr, flush=True)
        except Exception:
            pass
    try:
        path = os.path.join(tempfile.gettempdir(), "phonetouchpad.log")
        if os.path.exists(path) and os.path.getsize(path) > 262144:
            with open(path, "w", encoding="utf-8"):
                pass
        with open(path, "a", encoding="utf-8") as handle:
            handle.write(line + "\n")
    except OSError:
        pass


def parse_command(text: str) -> tuple:
    """Разобрать одну команду. Некорректный пакет — IndexError/ValueError/KeyError."""
    parts = text.split()
    if not parts:
        raise ValueError("empty")
    op = parts[0]
    if op == "M":
        if len(parts) != 3:
            raise IndexError("M")
        return ("M", int(parts[1]), int(parts[2]))
    if op == "C":
        if len(parts) != 3:
            raise IndexError("C")
        button, state = parts[1], parts[2]
        if button not in ("left", "right", "middle"):
            raise KeyError(button)
        if state not in ("down", "up"):
            raise ValueError(state)
        return ("C", button, state)
    if op == "T":
        if len(parts) != 2:
            raise IndexError("T")
        button = parts[1]
        if button not in ("left", "right"):
            raise KeyError(button)
        return ("T", button)
    if op == "S":
        if len(parts) != 3:
            raise IndexError("S")
        # S dy dx — единица уже в шагах колеса (120 = один щелчок).
        return ("S", int(parts[1]), int(parts[2]))
    raise ValueError(op)


def _register_socket(sock: socket.socket) -> None:
    with _sockets_lock:
        _sockets.append(sock)


def _unregister_socket(sock: socket.socket) -> None:
    with _sockets_lock:
        try:
            _sockets.remove(sock)
        except ValueError:
            pass


def close_all_sockets() -> None:
    with _sockets_lock:
        sockets = list(_sockets)
    for sock in sockets:
        try:
            sock.close()
        except OSError:
            pass


def _clamp(value: int, limit: int) -> int:
    if value > limit:
        return limit
    if value < -limit:
        return -limit
    return value


def _to_dword(value: int) -> int:
    value = _clamp(int(value), 2147483647)
    return value & 0xFFFFFFFF


if sys.platform == "win32":
    import ctypes
    from ctypes import wintypes

    # ULONG_PTR в MOUSEINPUT выравнивается на 8 байт. На 64-bit sizeof(INPUT) == 40,
    # на 32-bit == 28. Неверный размер — SendInput молча возвращает 0.
    _ULONG_PTR = ctypes.c_void_p

    class MOUSEINPUT(ctypes.Structure):
        _fields_ = (
            ("dx", wintypes.LONG),
            ("dy", wintypes.LONG),
            ("mouseData", wintypes.DWORD),
            ("dwFlags", wintypes.DWORD),
            ("time", wintypes.DWORD),
            ("dwExtraInfo", _ULONG_PTR),
        )

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = (
            ("wVk", wintypes.WORD),
            ("wScan", wintypes.WORD),
            ("dwFlags", wintypes.DWORD),
            ("time", wintypes.DWORD),
            ("dwExtraInfo", _ULONG_PTR),
        )

    class HARDWAREINPUT(ctypes.Structure):
        _fields_ = (
            ("uMsg", wintypes.DWORD),
            ("wParamL", wintypes.WORD),
            ("wParamH", wintypes.WORD),
        )

    class INPUT(ctypes.Structure):
        class _U(ctypes.Union):
            _fields_ = (
                ("mi", MOUSEINPUT),
                ("ki", KEYBDINPUT),
                ("hi", HARDWAREINPUT),
            )

        _anonymous_ = ("_u",)
        _fields_ = (
            ("type", wintypes.DWORD),
            ("_u", _U),
        )

    INPUT_MOUSE = 0
    MOUSEEVENTF_MOVE = 0x0001
    MOUSEEVENTF_LEFTDOWN = 0x0002
    MOUSEEVENTF_LEFTUP = 0x0004
    MOUSEEVENTF_RIGHTDOWN = 0x0008
    MOUSEEVENTF_RIGHTUP = 0x0010
    MOUSEEVENTF_MIDDLEDOWN = 0x0020
    MOUSEEVENTF_MIDDLEUP = 0x0040
    MOUSEEVENTF_WHEEL = 0x0800
    MOUSEEVENTF_HWHEEL = 0x01000

    _BUTTONS = {
        "left": (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP),
        "right": (MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP),
        "middle": (MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP),
    }

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    user32.SendInput.argtypes = (
        wintypes.UINT,
        ctypes.POINTER(INPUT),
        ctypes.c_int,
    )
    user32.SendInput.restype = wintypes.UINT

    _send_error_logged = False

    def init_platform() -> None:
        try:
            user32.SetProcessDPIAware()
        except Exception:
            pass
        size = ctypes.sizeof(INPUT)
        log(f"sizeof(INPUT)={size}")
        if size not in (28, 40):
            log("WARNING: unexpected INPUT size, cursor injection may fail")

    def _make_input(dx: int, dy: int, flags: int, data: int) -> INPUT:
        event = INPUT()
        event.type = INPUT_MOUSE
        event.mi.dx = _clamp(int(dx), 32767)
        event.mi.dy = _clamp(int(dy), 32767)
        event.mi.mouseData = _to_dword(data)
        event.mi.dwFlags = flags
        event.mi.time = 0
        event.mi.dwExtraInfo = None
        return event

    def _send(events: list[tuple[int, int, int, int]]) -> None:
        global _send_error_logged
        if not events:
            return
        batch = (INPUT * len(events))(*(_make_input(*item) for item in events))
        sent = user32.SendInput(len(events), batch, ctypes.sizeof(INPUT))
        if sent != len(events) and not _send_error_logged:
            _send_error_logged = True
            err = ctypes.get_last_error()
            log(f"SendInput sent {sent}/{len(events)} GetLastError={err}")

    def apply_command(parsed: tuple) -> None:
        op = parsed[0]
        if op == "M":
            dx = _clamp(parsed[1], 32767)
            dy = _clamp(parsed[2], 32767)
            if dx == 0 and dy == 0:
                return
            _send([(dx, dy, MOUSEEVENTF_MOVE, 0)])
            return
        if op == "C":
            down_flag, up_flag = _BUTTONS[parsed[1]]
            flag = down_flag if parsed[2] == "down" else up_flag
            _send([(0, 0, flag, 0)])
            return
        if op == "T":
            down_flag, up_flag = _BUTTONS[parsed[1]]
            _send([(0, 0, down_flag, 0), (0, 0, up_flag, 0)])
            return
        if op == "S":
            wheel_dy = int(parsed[1])
            wheel_dx = int(parsed[2])
            events: list[tuple[int, int, int, int]] = []
            if wheel_dy != 0:
                events.append((0, 0, MOUSEEVENTF_WHEEL, wheel_dy))
            if wheel_dx != 0:
                events.append((0, 0, MOUSEEVENTF_HWHEEL, wheel_dx))
            _send(events)
            return
        raise ValueError(op)

else:

    def init_platform() -> None:
        log("not Windows: packets are parsed and ignored (no SendInput)")

    def apply_command(parsed: tuple) -> None:
        return None


def discovery_loop() -> None:
    while not stop_event.is_set():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            sock.settimeout(0.5)
            sock.bind(("0.0.0.0", DISCOVERY_PORT))
        except OSError as exc:
            log(f"discovery bind {DISCOVERY_PORT} failed: {exc}")
            sock.close()
            if stop_event.wait(2.0):
                return
            continue
        _register_socket(sock)
        hostname = socket.gethostname().replace("\r", " ").replace("\n", " ")
        log(f"discovery listening on 0.0.0.0:{DISCOVERY_PORT} as {hostname}")
        try:
            while not stop_event.is_set():
                try:
                    data, addr = sock.recvfrom(512)
                except socket.timeout:
                    continue
                except OSError:
                    break
                if data.strip() != DISCOVERY_TOKEN:
                    continue
                payload = f"PC:{hostname}".encode("utf-8")
                try:
                    sock.sendto(payload, addr)
                    log(f"reply PC:{hostname} -> {addr[0]}:{addr[1]}")
                except OSError as exc:
                    log(f"discovery reply failed: {exc}")
        finally:
            _unregister_socket(sock)
            try:
                sock.close()
            except OSError:
                pass


def command_loop() -> None:
    while not stop_event.is_set():
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 65536)
            sock.settimeout(0.5)
            sock.bind(("0.0.0.0", COMMAND_PORT))
        except OSError as exc:
            log(f"command bind {COMMAND_PORT} failed: {exc}")
            sock.close()
            if stop_event.wait(2.0):
                return
            continue
        _register_socket(sock)
        log(f"commands listening on 0.0.0.0:{COMMAND_PORT} SO_RCVBUF=65536")
        try:
            while not stop_event.is_set():
                try:
                    data, _addr = sock.recvfrom(1024)
                except socket.timeout:
                    continue
                except OSError:
                    break
                try:
                    text = data.decode("utf-8").strip()
                    apply_command(parse_command(text))
                except (IndexError, ValueError, KeyError, UnicodeDecodeError):
                    continue
                except Exception as exc:
                    log(f"command dropped: {exc}")
        finally:
            _unregister_socket(sock)
            try:
                sock.close()
            except OSError:
                pass


def _make_tray_image():
    from PIL import Image, ImageDraw

    image = Image.new("RGBA", (64, 64), (17, 17, 34, 255))
    draw = ImageDraw.Draw(image)
    draw.rectangle((6, 6, 57, 57), fill=(34, 34, 68, 255))
    draw.rectangle((14, 26, 50, 42), fill=(142, 183, 255, 255))
    return image


def run_tray() -> bool:
    try:
        import pystray
        from PIL import Image, ImageDraw  # noqa: F401
    except Exception as exc:
        log(f"tray disabled ({exc})")
        return False
    if sys.platform == "win32":
        # Явный импорт, чтобы PyInstaller забрал backend трея.
        try:
            import pystray._win32  # noqa: F401
        except Exception as exc:
            log(f"pystray win32 backend: {exc}")
            return False
    try:
        image = _make_tray_image()
    except Exception as exc:
        log(f"tray icon failed ({exc})")
        return False

    def on_exit(icon: object, _item: object) -> None:
        log("exit from tray")
        stop_event.set()
        close_all_sockets()
        try:
            icon.stop()  # type: ignore[attr-defined]
        except Exception:
            pass

    icon = pystray.Icon(
        "phonetouchpad",
        image,
        "Phone Touchpad",
        menu=pystray.Menu(pystray.MenuItem("Выход", on_exit)),
    )
    log("tray icon running")
    try:
        icon.run()
    except Exception as exc:
        log(f"tray stopped: {exc}")
        return False
    return True


def main() -> None:
    log(f"Phone Touchpad host start pid={os.getpid()} py={sys.version.split()[0]}")
    init_platform()
    threading.Thread(target=discovery_loop, name="discovery", daemon=True).start()
    threading.Thread(target=command_loop, name="commands", daemon=True).start()
    if run_tray():
        stop_event.set()
        close_all_sockets()
        return
    log("no tray — process stays up; end it from Task Manager or Ctrl+C")
    try:
        while not stop_event.is_set():
            stop_event.wait(0.5)
    except KeyboardInterrupt:
        log("keyboard interrupt")
        stop_event.set()
        close_all_sockets()


if __name__ == "__main__":
    main()
