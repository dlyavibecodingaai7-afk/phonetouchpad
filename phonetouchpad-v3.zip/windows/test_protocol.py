"""Проверка разбора команд без Windows и без сети: python test_protocol.py"""

import importlib.util
from pathlib import Path

path = Path(__file__).with_name("mouse_host.py")
spec = importlib.util.spec_from_file_location("mouse_host", path)
assert spec and spec.loader
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

assert mod.parse_command("M -2 3") == ("M", -2, 3)
assert mod.parse_command("C left down") == ("C", "left", "down")
assert mod.parse_command("C middle up") == ("C", "middle", "up")
assert mod.parse_command("T right") == ("T", "right")
assert mod.parse_command("S -40 80") == ("S", -40, 80)
assert mod.parse_command("  M   0  -1  ") == ("M", 0, -1)

bad = ["", "M 1", "C left", "T middle", "T left extra", "S 1", "NOPE", "M a b", "C no down"]
for sample in bad:
    try:
        mod.parse_command(sample)
    except (IndexError, ValueError, KeyError):
        continue
    raise SystemExit(f"should reject {sample!r}")

print("protocol parse ok")
