package com.example.phonetouchpad

import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * Телефон — тачпад. Протокол совпадает с mouse_host.py:
 * FIND_PC на UDP/50506, команды M/C/T/S на UDP/50505.
 *
 * Кроме обязательного 255.255.255.255 пакет FIND_PC уходит и на
 * широковещательный адрес подсети. На Android 10+ limited broadcast
 * часто отбрасывается, формат пакета при этом не меняется.
 * Сокет привязывается к Wi‑Fi через Network.bindSocket, чтобы VPN
 * и мобильные данные не уводили UDP с локальной сети.
 */
class MainActivity : AppCompatActivity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val commands = Channel<String>(2048)

    @Volatile
    private var targetAddress: InetAddress? = null

    @Volatile
    private var reopenSocket = true

    @Volatile
    private var cmdSocket: DatagramSocket? = null

    private lateinit var settings: AppSettings
    private lateinit var haptics: Haptics
    private var appliedTheme = AppSettings.THEME_SYSTEM

    private lateinit var adapter: ArrayAdapter<Pc>
    private lateinit var statusText: TextView
    private lateinit var findButton: Button
    private lateinit var settingsButton: Button
    private lateinit var pcList: ListView
    private lateinit var connectPanel: View
    private lateinit var padPanel: View
    private lateinit var touchpad: View
    private lateinit var buttonsRow: View
    private lateinit var leftButton: Button
    private lateinit var rightButton: Button
    private lateinit var ipInput: EditText
    private lateinit var ipButton: Button

    private var pointerSpeed = 1.6f
    private var acceleration = 0f
    private var scrollSpeed = 1f
    private var naturalScroll = false
    private var tapToClick = true
    private var dragEnabled = true
    private var twoFingerRight = true
    private var doubleTapMs = 300L
    private var hapticsOn = true
    private var hapticSingleOn = true
    private var hapticDoubleOn = true
    private var hapticRightOn = true
    private var hapticStrength = 60
    private var hapticDuration = 15
    private var doubleCandidate = false

    private var searching = false
    private var dragging = false

    private var mode = Mode.IDLE
    private var primaryId = -1
    private var downTime = 0L
    private var originX = 0f
    private var originY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var movedBeyondTap = false
    private var suppressClick = false
    private var fracX = 0f
    private var fracY = 0f
    private var lastTapUpTime = 0L
    private var lastTapX = 0f
    private var lastTapY = 0f

    private var twoDownTime = 0L
    private var twoOriginX = 0f
    private var twoOriginY = 0f
    private var lastMidX = 0f
    private var lastMidY = 0f
    private var twoMoved = false
    private var scrollAccX = 0f
    private var scrollAccY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        settings = AppSettings(this)
        ThemeHelper.applyTheme(this, settings)
        appliedTheme = settings.themeMode
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        ThemeHelper.styleSystemBars(this)
        haptics = Haptics(this)

        statusText = findViewById(R.id.statusText)
        findButton = findViewById(R.id.findButton)
        settingsButton = findViewById(R.id.settingsButton)
        pcList = findViewById(R.id.pcList)
        connectPanel = findViewById(R.id.connectPanel)
        padPanel = findViewById(R.id.padPanel)
        touchpad = findViewById(R.id.touchpad)
        buttonsRow = findViewById(R.id.buttonsRow)
        leftButton = findViewById(R.id.leftButton)
        rightButton = findViewById(R.id.rightButton)
        ipInput = findViewById(R.id.ipInput)
        ipButton = findViewById(R.id.ipButton)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        adapter = ArrayAdapter(this, R.layout.pc_item, android.R.id.text1, ArrayList())
        pcList.adapter = adapter
        pcList.setOnItemClickListener { _, _, position, _ ->
            val pc = adapter.getItem(position) ?: return@setOnItemClickListener
            val host = pc.address.hostAddress
            if (host != null) settings.lastIp = host
            connect(pc.address, pc.name.ifBlank { host ?: "" })
        }
        findButton.setOnClickListener { findPcs() }
        settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        ipButton.setOnClickListener {
            val text = ipInput.text.toString().trim()
            val address = parseIp(text)
            if (address == null) {
                statusText.text = "Введите IP вида 192.168.1.10"
                return@setOnClickListener
            }
            settings.lastIp = text
            connect(address, text)
        }
        ipInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                ipButton.performClick()
                true
            } else {
                false
            }
        }
        leftButton.setOnClickListener {
            sendCmd("T left")
            vibrateSingle()
        }
        rightButton.setOnClickListener {
            sendCmd("T right")
            vibrateRight()
        }
        touchpad.setOnTouchListener { _, event ->
            onPad(event)
            true
        }

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    if (padPanel.visibility == View.VISIBLE) {
                        showConnect()
                        statusText.text = "Выберите компьютер"
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            },
        )

        loadSettings()
        startSender()

        ipInput.setText(settings.lastIp)
        val savedIp = parseIp(settings.lastIp)
        val restorePad = savedInstanceState?.getBoolean(STATE_PAD, false) == true
        if (savedIp != null && (restorePad || settings.autoConnect)) {
            connect(savedIp, settings.lastIp)
        } else {
            findPcs()
        }
    }

    override fun onResume() {
        super.onResume()
        if (settings.themeMode != appliedTheme) {
            recreate()
            return
        }
        loadSettings()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(STATE_PAD, padPanel.visibility == View.VISIBLE)
    }

    private fun loadSettings() {
        pointerSpeed = settings.pointerSpeed / 100f
        acceleration = settings.acceleration / 100f
        scrollSpeed = settings.scrollSpeed / 100f
        naturalScroll = settings.naturalScroll
        tapToClick = settings.tapToClick
        dragEnabled = settings.dragEnabled
        twoFingerRight = settings.twoFingerRightClick
        doubleTapMs = settings.doubleTapMs.toLong()
        hapticsOn = settings.hapticsEnabled
        hapticSingleOn = settings.hapticSingle
        hapticDoubleOn = settings.hapticDouble
        hapticRightOn = settings.hapticRight
        hapticStrength = settings.hapticStrength
        hapticDuration = settings.hapticDuration
        touchpad.keepScreenOn = settings.keepScreenOn
        buttonsRow.visibility = if (settings.showMouseButtons) View.VISIBLE else View.GONE
    }

    private fun vibrateSingle() {
        if (hapticsOn && hapticSingleOn) haptics.single(hapticStrength, hapticDuration)
    }

    private fun vibrateDouble() {
        if (hapticsOn && hapticDoubleOn) haptics.double(hapticStrength, hapticDuration)
    }

    private fun vibrateRight() {
        if (hapticsOn && hapticRightOn) haptics.single(hapticStrength, hapticDuration)
    }

    private fun connect(address: InetAddress, label: String) {
        targetAddress = address
        reopenSocket = true
        statusText.text = "Подключено: $label"
        showPad()
    }

    private fun showPad() {
        connectPanel.visibility = View.GONE
        padPanel.visibility = View.VISIBLE
        hideKeyboard()
    }

    private fun showConnect() {
        releaseDrag()
        padPanel.visibility = View.GONE
        connectPanel.visibility = View.VISIBLE
    }

    private fun hideKeyboard() {
        val imm = getSystemService(InputMethodManager::class.java)
        imm?.hideSoftInputFromWindow(ipInput.windowToken, 0)
        ipInput.clearFocus()
    }

    private fun parseIp(text: String): InetAddress? {
        val parts = text.split(".")
        if (parts.size != 4) return null
        val bytes = ByteArray(4)
        for (i in 0 until 4) {
            val part = parts[i]
            if (part.isEmpty() || part.length > 3 || !part.all { ch -> ch in '0'..'9' }) return null
            val n = part.toInt()
            if (n > 255) return null
            bytes[i] = n.toByte()
        }
        return try {
            InetAddress.getByAddress(bytes)
        } catch (_: Exception) {
            null
        }
    }

    override fun onPause() {
        releaseDrag()
        super.onPause()
    }

    override fun onDestroy() {
        if (dragging) {
            val addr = targetAddress
            val sock = cmdSocket
            dragging = false
            if (addr != null && sock != null && !sock.isClosed) {
                val worker = Thread {
                    try {
                        val bytes = "C left up".toByteArray(Charsets.UTF_8)
                        sock.send(DatagramPacket(bytes, bytes.size, addr, COMMAND_PORT))
                    } catch (_: Exception) {
                    }
                }
                worker.start()
                try {
                    worker.join(200)
                } catch (_: InterruptedException) {
                }
            }
        }
        commands.close()
        scope.cancel()
        try {
            cmdSocket?.close()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    private fun findPcs() {
        if (searching) return
        searching = true
        releaseDrag()
        findButton.isEnabled = false
        showConnect()
        statusText.text = "Поиск компьютеров…"
        scope.launch {
            val found = try {
                withContext(Dispatchers.IO) { discover() }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                emptyList()
            }
            if (!isActive || isDestroyed) return@launch
            adapter.clear()
            adapter.addAll(found)
            adapter.notifyDataSetChanged()
            statusText.text = if (found.isEmpty()) {
                "Компьютеры не найдены. Введите IP компьютера вручную ниже."
            } else {
                "Найдено: ${found.size}. Выберите компьютер"
            }
            findButton.isEnabled = true
            searching = false
        }
    }

    private fun discover(): List<Pc> {
        val socket = DatagramSocket()
        val lock = acquireMulticast()
        val found = LinkedHashMap<String, Pc>()
        try {
            socket.broadcast = true
            socket.soTimeout = 200
            try {
                wifiNetwork()?.bindSocket(socket)
            } catch (_: Exception) {
            }
            val payload = "FIND_PC".toByteArray(Charsets.UTF_8)
            val targets = LinkedHashMap<String, InetAddress>()
            val global = InetAddress.getByName("255.255.255.255")
            global.hostAddress?.let { targets[it] = global }
            for (extra in ipv4Broadcasts()) {
                extra.hostAddress?.let { targets.putIfAbsent(it, extra) }
            }
            for (address in targets.values) {
                try {
                    socket.send(DatagramPacket(payload, payload.size, address, DISCOVERY_PORT))
                } catch (_: Exception) {
                }
            }
            val buffer = ByteArray(256)
            val deadline = System.nanoTime() + 2_000_000_000L
            while (System.nanoTime() < deadline) {
                val packet = DatagramPacket(buffer, buffer.size)
                try {
                    socket.receive(packet)
                } catch (_: Exception) {
                    continue
                }
                val text = String(packet.data, packet.offset, packet.length, Charsets.UTF_8).trim()
                if (!text.startsWith("PC:")) continue
                val name = text.substring(3).trim()
                val remote = packet.address ?: continue
                val key = remote.hostAddress ?: continue
                found[key] = Pc(name, remote)
            }
        } finally {
            try {
                if (lock != null && lock.isHeld) lock.release()
            } catch (_: Exception) {
            }
            socket.close()
        }
        return found.values.toList()
    }

    private fun startSender() {
        scope.launch(Dispatchers.IO) {
            var socket = openCommandSocket()
            cmdSocket = socket
            try {
                for (message in commands) {
                    if (reopenSocket || socket.isClosed) {
                        reopenSocket = false
                        try {
                            socket.close()
                        } catch (_: Exception) {
                        }
                        socket = openCommandSocket()
                        cmdSocket = socket
                    }
                    val address = targetAddress ?: continue
                    try {
                        val bytes = message.toByteArray(Charsets.UTF_8)
                        socket.send(DatagramPacket(bytes, bytes.size, address, COMMAND_PORT))
                    } catch (_: Exception) {
                    }
                }
            } finally {
                try {
                    socket.close()
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun openCommandSocket(): DatagramSocket {
        val socket = DatagramSocket()
        try {
            socket.trafficClass = 0x10
        } catch (_: Exception) {
        }
        try {
            wifiNetwork()?.bindSocket(socket)
        } catch (_: Exception) {
        }
        return socket
    }

    private fun sendCmd(text: String) {
        commands.trySend(text)
    }

    private fun onPad(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                primaryId = event.getPointerId(0)
                downTime = event.eventTime
                originX = event.x
                originY = event.y
                lastX = event.x
                lastY = event.y
                movedBeyondTap = false
                suppressClick = false
                fracX = 0f
                fracY = 0f
                val gap = event.eventTime - lastTapUpTime
                val near = hypot(event.x - lastTapX, event.y - lastTapY) <= 80f
                val second = lastTapUpTime != 0L && gap in 0L..doubleTapMs && near
                doubleCandidate = second
                if (second && dragEnabled) {
                    mode = Mode.DRAG
                    dragging = true
                    lastTapUpTime = 0L
                    sendCmd("C left down")
                    vibrateDouble()
                } else {
                    mode = Mode.ONE
                }
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount >= 2 && mode != Mode.TWO) beginTwo(event)
            }

            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2) {
                    if (mode != Mode.TWO) beginTwo(event)
                    moveTwo(event)
                } else if (mode == Mode.ONE || mode == Mode.DRAG) {
                    moveOne(event)
                }
            }

            MotionEvent.ACTION_POINTER_UP -> {
                if (mode == Mode.TWO && event.pointerCount - 1 < 2) {
                    maybeRightClick(event)
                    val stay = if (event.actionIndex == 0) 1 else 0
                    if (stay < event.pointerCount) {
                        primaryId = event.getPointerId(stay)
                        lastX = event.getX(stay)
                        lastY = event.getY(stay)
                        originX = lastX
                        originY = lastY
                        downTime = event.eventTime
                        movedBeyondTap = true
                        suppressClick = true
                        fracX = 0f
                        fracY = 0f
                        mode = Mode.ONE
                    } else {
                        mode = Mode.IDLE
                    }
                }
            }

            MotionEvent.ACTION_UP -> finishPointer(event)

            MotionEvent.ACTION_CANCEL -> {
                releaseDrag()
                mode = Mode.IDLE
                suppressClick = false
                lastTapUpTime = 0L
                doubleCandidate = false
            }
        }
    }

    private fun finishPointer(event: MotionEvent) {
        if (mode == Mode.TWO) {
            maybeRightClick(event)
            mode = Mode.IDLE
            return
        }
        if (dragging) {
            releaseDrag()
            mode = Mode.IDLE
            return
        }
        val quick = event.eventTime - downTime < 200L
        val dist = hypot(event.x - originX, event.y - originY)
        if (tapToClick && mode == Mode.ONE && !suppressClick && !movedBeyondTap && quick && dist <= 12f) {
            sendCmd("T left")
            if (doubleCandidate) vibrateDouble() else vibrateSingle()
            doubleCandidate = false
            lastTapUpTime = event.eventTime
            lastTapX = event.x
            lastTapY = event.y
        } else {
            lastTapUpTime = 0L
        }
        mode = Mode.IDLE
        suppressClick = false
    }

    private fun beginTwo(event: MotionEvent) {
        if (dragging) releaseDrag()
        mode = Mode.TWO
        twoDownTime = event.eventTime
        twoMoved = false
        scrollAccX = 0f
        scrollAccY = 0f
        val mid = midpoint(event)
        twoOriginX = mid.first
        twoOriginY = mid.second
        lastMidX = mid.first
        lastMidY = mid.second
        lastTapUpTime = 0L
    }

    private fun moveOne(event: MotionEvent) {
        val index = event.findPointerIndex(primaryId).let { if (it >= 0) it else 0 }
        var prevX = lastX
        var prevY = lastY
        for (h in 0 until event.historySize) {
            val x = event.getHistoricalX(index, h)
            val y = event.getHistoricalY(index, h)
            stepMove(x - prevX, y - prevY)
            if (hypot(x - originX, y - originY) > 12f) movedBeyondTap = true
            prevX = x
            prevY = y
        }
        val x = event.getX(index)
        val y = event.getY(index)
        stepMove(x - prevX, y - prevY)
        if (hypot(x - originX, y - originY) > 12f) movedBeyondTap = true
        lastX = x
        lastY = y
    }

    private fun stepMove(rawDx: Float, rawDy: Float) {
        if (rawDx == 0f && rawDy == 0f) return
        val gain = if (acceleration > 0f) {
            val speed = hypot(rawDx, rawDy)
            pointerSpeed * (1f + acceleration * minOf(speed / 12f, 2.5f))
        } else {
            pointerSpeed
        }
        fracX += rawDx * gain
        fracY += rawDy * gain
        if (abs(fracX) > 0.5f || abs(fracY) > 0.5f) {
            val ix = fracX.roundToInt()
            val iy = fracY.roundToInt()
            if (ix != 0 || iy != 0) {
                sendCmd("M $ix $iy")
                fracX -= ix
                fracY -= iy
            }
        }
    }

    private fun moveTwo(event: MotionEvent) {
        if (event.pointerCount < 2) return
        val mid = midpoint(event)
        val dx = mid.first - lastMidX
        val dy = mid.second - lastMidY
        lastMidX = mid.first
        lastMidY = mid.second
        if (hypot(mid.first - twoOriginX, mid.second - twoOriginY) > 12f) twoMoved = true
        scrollAccX += dx
        scrollAccY += dy
        val stepsX = (scrollAccX / 8f).toInt()
        val stepsY = (scrollAccY / 8f).toInt()
        if (stepsX != 0 || stepsY != 0) {
            scrollAccX -= stepsX * 8f
            scrollAccY -= stepsY * 8f
            val dir = if (naturalScroll) -1f else 1f
            val sy = (-stepsY * 40f * scrollSpeed * dir).roundToInt()
            val sx = (stepsX * 40f * scrollSpeed * dir).roundToInt()
            if (sy != 0 || sx != 0) sendCmd("S $sy $sx")
            twoMoved = true
        }
    }

    private fun maybeRightClick(event: MotionEvent) {
        if (!twoFingerRight) return
        if (twoMoved) return
        if (event.eventTime - twoDownTime >= 200L) return
        val mid = midpoint(event)
        if (hypot(mid.first - twoOriginX, mid.second - twoOriginY) <= 12f) {
            sendCmd("T right")
            vibrateRight()
            twoMoved = true
        }
    }

    private fun midpoint(event: MotionEvent): Pair<Float, Float> {
        val count = minOf(2, event.pointerCount)
        if (count == 0) return 0f to 0f
        var x = 0f
        var y = 0f
        for (i in 0 until count) {
            x += event.getX(i)
            y += event.getY(i)
        }
        return x / count to y / count
    }

    private fun releaseDrag() {
        if (!dragging) return
        dragging = false
        sendCmd("C left up")
    }

    private fun wifiNetwork(): Network? {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return null
        var fallback: Network? = null
        for (network in cm.allNetworks) {
            val caps = cm.getNetworkCapabilities(network) ?: continue
            val vpn = caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) && !vpn) return network
            if (!vpn && fallback == null) fallback = network
        }
        val active = cm.activeNetwork ?: return fallback
        val caps = cm.getNetworkCapabilities(active)
        if (caps != null && !caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return active
        return fallback
    }

    private fun ipv4Broadcasts(): List<InetAddress> {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return emptyList()
        val network = wifiNetwork() ?: cm.activeNetwork ?: return emptyList()
        val props = cm.getLinkProperties(network) ?: return emptyList()
        val result = ArrayList<InetAddress>()
        for (link in props.linkAddresses) {
            val addr = link.address
            if (addr is Inet4Address && !addr.isLoopbackAddress) {
                val prefix = link.prefixLength
                if (prefix in 1..31) {
                    try {
                        result.add(broadcastAddress(addr, prefix))
                    } catch (_: Exception) {
                    }
                }
            }
        }
        return result
    }

    private fun broadcastAddress(addr: Inet4Address, prefix: Int): InetAddress {
        val ip = ByteBuffer.wrap(addr.address).order(ByteOrder.BIG_ENDIAN).int
        val mask = (-1 shl (32 - prefix))
        val broadcast = ip or mask.inv()
        val bytes = ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(broadcast).array()
        return InetAddress.getByAddress(bytes)
    }

    private fun acquireMulticast(): WifiManager.MulticastLock? {
        return try {
            val wifi = applicationContext.getSystemService(WifiManager::class.java) ?: return null
            wifi.createMulticastLock("phonetouchpad").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {
            null
        }
    }

    private enum class Mode { IDLE, ONE, TWO, DRAG }

    private companion object {
        const val DISCOVERY_PORT = 50506
        const val COMMAND_PORT = 50505
        const val STATE_PAD = "pad"
    }
}

data class Pc(val name: String, val address: InetAddress) {
    override fun toString(): String {
        val host = address.hostAddress ?: "?"
        return if (name.isBlank()) host else "$name — $host"
    }
}
