package com.example.phonetouchpad

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.WindowCompat
import com.google.android.material.color.DynamicColors

/** Все настройки приложения. Хранятся в SharedPreferences "touchpad". */
class AppSettings(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("touchpad", Context.MODE_PRIVATE)

    var themeMode: Int
        get() = prefs.getInt("theme", THEME_SYSTEM)
        set(value) {
            prefs.edit().putInt("theme", value).apply()
        }

    /** Скорость курсора в процентах (160 = как было раньше). */
    var pointerSpeed: Int
        get() = prefs.getInt("pointer_speed", 160)
        set(value) {
            prefs.edit().putInt("pointer_speed", value).apply()
        }

    /** Ускорение курсора, 0..100. 0 = выключено. */
    var acceleration: Int
        get() = prefs.getInt("acceleration", 0)
        set(value) {
            prefs.edit().putInt("acceleration", value).apply()
        }

    /** Скорость прокрутки в процентах (100 = как было раньше). */
    var scrollSpeed: Int
        get() = prefs.getInt("scroll_speed", 100)
        set(value) {
            prefs.edit().putInt("scroll_speed", value).apply()
        }

    var naturalScroll: Boolean
        get() = prefs.getBoolean("natural_scroll", false)
        set(value) {
            prefs.edit().putBoolean("natural_scroll", value).apply()
        }

    var tapToClick: Boolean
        get() = prefs.getBoolean("tap_to_click", true)
        set(value) {
            prefs.edit().putBoolean("tap_to_click", value).apply()
        }

    var dragEnabled: Boolean
        get() = prefs.getBoolean("drag_enabled", true)
        set(value) {
            prefs.edit().putBoolean("drag_enabled", value).apply()
        }

    var twoFingerRightClick: Boolean
        get() = prefs.getBoolean("two_finger_right", true)
        set(value) {
            prefs.edit().putBoolean("two_finger_right", value).apply()
        }

    /** Интервал двойного тапа, мс. */
    var doubleTapMs: Int
        get() = prefs.getInt("double_tap_ms", 300)
        set(value) {
            prefs.edit().putInt("double_tap_ms", value).apply()
        }

    var hapticsEnabled: Boolean
        get() = prefs.getBoolean("haptics", true)
        set(value) {
            prefs.edit().putBoolean("haptics", value).apply()
        }

    var hapticSingle: Boolean
        get() = prefs.getBoolean("haptic_single", true)
        set(value) {
            prefs.edit().putBoolean("haptic_single", value).apply()
        }

    var hapticDouble: Boolean
        get() = prefs.getBoolean("haptic_double", true)
        set(value) {
            prefs.edit().putBoolean("haptic_double", value).apply()
        }

    var hapticRight: Boolean
        get() = prefs.getBoolean("haptic_right", true)
        set(value) {
            prefs.edit().putBoolean("haptic_right", value).apply()
        }

    /** Сила вибрации, 5..100 %. */
    var hapticStrength: Int
        get() = prefs.getInt("haptic_strength", 60)
        set(value) {
            prefs.edit().putInt("haptic_strength", value).apply()
        }

    /** Длительность одного импульса, мс. */
    var hapticDuration: Int
        get() = prefs.getInt("haptic_duration", 15)
        set(value) {
            prefs.edit().putInt("haptic_duration", value).apply()
        }

    var keepScreenOn: Boolean
        get() = prefs.getBoolean("keep_screen_on", true)
        set(value) {
            prefs.edit().putBoolean("keep_screen_on", value).apply()
        }

    var showMouseButtons: Boolean
        get() = prefs.getBoolean("show_buttons", false)
        set(value) {
            prefs.edit().putBoolean("show_buttons", value).apply()
        }

    var autoConnect: Boolean
        get() = prefs.getBoolean("auto_connect", false)
        set(value) {
            prefs.edit().putBoolean("auto_connect", value).apply()
        }

    /** Последний IP компьютера (тот же ключ "ip", что и в прошлой версии). */
    var lastIp: String
        get() = prefs.getString("ip", "") ?: ""
        set(value) {
            prefs.edit().putString("ip", value).apply()
        }

    /** Сбрасывает всё, кроме последнего IP. */
    fun resetToDefaults() {
        val ip = lastIp
        prefs.edit().clear().putString("ip", ip).apply()
    }

    companion object {
        const val THEME_SYSTEM = 0
        const val THEME_LIGHT = 1
        const val THEME_DARK = 2
        const val THEME_DYNAMIC = 3
    }
}

/** Применение темы: светлая/тёмная/системная и Material You. */
object ThemeHelper {

    fun nightModeFor(theme: Int): Int = when (theme) {
        AppSettings.THEME_LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
        AppSettings.THEME_DARK -> AppCompatDelegate.MODE_NIGHT_YES
        else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
    }

    /** Вызывать до super.onCreate(). */
    fun applyTheme(activity: Activity, settings: AppSettings) {
        AppCompatDelegate.setDefaultNightMode(nightModeFor(settings.themeMode))
        if (settings.themeMode == AppSettings.THEME_DYNAMIC) {
            DynamicColors.applyToActivityIfAvailable(activity)
        }
    }

    /** Вызывать после setContentView(): тёмные/светлые значки в строке состояния. */
    fun styleSystemBars(activity: Activity) {
        val night = (activity.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val controller = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        controller.isAppearanceLightStatusBars = !night
        controller.isAppearanceLightNavigationBars = !night
    }
}
