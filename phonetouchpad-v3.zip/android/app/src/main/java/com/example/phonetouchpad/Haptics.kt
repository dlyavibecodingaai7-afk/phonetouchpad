package com.example.phonetouchpad

import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator

/** Вибро-отклик с настраиваемой силой (1..100 %) и длительностью импульса. */
class Haptics(context: Context) {

    private val vibrator: Vibrator? = try {
        context.applicationContext.getSystemService(Vibrator::class.java)
    } catch (_: Exception) {
        null
    }

    private fun amplitude(strengthPercent: Int): Int {
        val v = vibrator ?: return VibrationEffect.DEFAULT_AMPLITUDE
        return if (v.hasAmplitudeControl()) {
            (strengthPercent * 255 / 100).coerceIn(1, 255)
        } else {
            VibrationEffect.DEFAULT_AMPLITUDE
        }
    }

    fun single(strengthPercent: Int, durationMs: Int) {
        val v = vibrator ?: return
        try {
            if (!v.hasVibrator()) return
            v.vibrate(VibrationEffect.createOneShot(durationMs.toLong(), amplitude(strengthPercent)))
        } catch (_: Exception) {
        }
    }

    fun double(strengthPercent: Int, durationMs: Int) {
        val v = vibrator ?: return
        try {
            if (!v.hasVibrator()) return
            val amp = amplitude(strengthPercent)
            val d = durationMs.toLong()
            val timings = longArrayOf(0L, d, 45L, d)
            val amplitudes = intArrayOf(0, amp, 0, amp)
            v.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
        } catch (_: Exception) {
        }
    }
}
