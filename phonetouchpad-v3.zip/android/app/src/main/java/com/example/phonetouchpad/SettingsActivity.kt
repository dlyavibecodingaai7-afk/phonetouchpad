package com.example.phonetouchpad

import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.color.DynamicColors
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import kotlin.math.roundToInt

class SettingsActivity : AppCompatActivity() {

    private lateinit var settings: AppSettings
    private lateinit var haptics: Haptics

    override fun onCreate(savedInstanceState: Bundle?) {
        settings = AppSettings(this)
        ThemeHelper.applyTheme(this, settings)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        ThemeHelper.styleSystemBars(this)
        haptics = Haptics(this)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.settingsRoot)) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }

        setupTheme()
        setupCursor()
        setupScroll()
        setupGestures()
        setupHaptics()
        setupScreen()

        findViewById<Button>(R.id.resetButton).setOnClickListener {
            settings.resetToDefaults()
            ThemeHelper.applyTheme(this, settings)
            recreate()
        }
    }

    private fun setupTheme() {
        val group = findViewById<RadioGroup>(R.id.themeGroup)
        val dynamic = findViewById<RadioButton>(R.id.themeDynamic)
        if (!DynamicColors.isDynamicColorAvailable()) {
            dynamic.isEnabled = false
            dynamic.text = "Material You (недоступно на этом телефоне)"
        }
        val checked = when (settings.themeMode) {
            AppSettings.THEME_LIGHT -> R.id.themeLight
            AppSettings.THEME_DARK -> R.id.themeDark
            AppSettings.THEME_DYNAMIC -> R.id.themeDynamic
            else -> R.id.themeSystem
        }
        group.check(checked)
        group.setOnCheckedChangeListener { _, id ->
            val mode = when (id) {
                R.id.themeLight -> AppSettings.THEME_LIGHT
                R.id.themeDark -> AppSettings.THEME_DARK
                R.id.themeDynamic -> AppSettings.THEME_DYNAMIC
                else -> AppSettings.THEME_SYSTEM
            }
            if (mode != settings.themeMode) {
                val oldNight = ThemeHelper.nightModeFor(settings.themeMode)
                settings.themeMode = mode
                ThemeHelper.applyTheme(this, settings)
                if (oldNight == ThemeHelper.nightModeFor(mode)) {
                    recreate()
                }
            }
        }
    }

    private fun setupCursor() {
        val box = findViewById<LinearLayout>(R.id.cursorRows)
        addSlider(box, "Скорость курсора", 30, 400, 5, settings.pointerSpeed, { "$it%" }) {
            settings.pointerSpeed = it
        }
        addSlider(box, "Ускорение курсора", 0, 100, 5, settings.acceleration, { if (it == 0) "выкл" else "$it%" }) {
            settings.acceleration = it
        }
    }

    private fun setupScroll() {
        val box = findViewById<LinearLayout>(R.id.scrollRows)
        addSlider(box, "Скорость прокрутки", 30, 300, 10, settings.scrollSpeed, { "$it%" }) {
            settings.scrollSpeed = it
        }
        addSwitch(box, "Натуральная прокрутка (как в телефоне)", settings.naturalScroll) {
            settings.naturalScroll = it
        }
    }

    private fun setupGestures() {
        val box = findViewById<LinearLayout>(R.id.gestureRows)
        addSwitch(box, "Тап — левый клик", settings.tapToClick) { settings.tapToClick = it }
        addSwitch(box, "Двойной тап с удержанием — перетаскивание", settings.dragEnabled) {
            settings.dragEnabled = it
        }
        addSwitch(box, "Тап двумя пальцами — правый клик", settings.twoFingerRightClick) {
            settings.twoFingerRightClick = it
        }
        addSlider(box, "Интервал двойного тапа", 150, 500, 10, settings.doubleTapMs, { "$it мс" }) {
            settings.doubleTapMs = it
        }
    }

    private fun setupHaptics() {
        val box = findViewById<LinearLayout>(R.id.hapticRows)
        addSwitch(box, "Вибро-отклик", settings.hapticsEnabled) { settings.hapticsEnabled = it }
        addSwitch(box, "На одиночный тап", settings.hapticSingle) { settings.hapticSingle = it }
        addSwitch(box, "На двойной тап", settings.hapticDouble) { settings.hapticDouble = it }
        addSwitch(box, "На правый клик", settings.hapticRight) { settings.hapticRight = it }
        addSlider(box, "Сила вибрации", 5, 100, 5, settings.hapticStrength, { "$it%" }) {
            settings.hapticStrength = it
        }
        addSlider(box, "Длительность импульса", 5, 60, 5, settings.hapticDuration, { "$it мс" }) {
            settings.hapticDuration = it
        }
        findViewById<Button>(R.id.testSingleButton).setOnClickListener {
            haptics.single(settings.hapticStrength, settings.hapticDuration)
        }
        findViewById<Button>(R.id.testDoubleButton).setOnClickListener {
            haptics.double(settings.hapticStrength, settings.hapticDuration)
        }
    }

    private fun setupScreen() {
        val box = findViewById<LinearLayout>(R.id.screenRows)
        addSwitch(box, "Не гасить экран на тачпаде", settings.keepScreenOn) {
            settings.keepScreenOn = it
        }
        addSwitch(box, "Кнопки мыши под тачпадом", settings.showMouseButtons) {
            settings.showMouseButtons = it
        }
        addSwitch(box, "Подключаться к последнему компьютеру при запуске", settings.autoConnect) {
            settings.autoConnect = it
        }
    }

    private fun addSwitch(
        parent: LinearLayout,
        title: String,
        initial: Boolean,
        onChange: (Boolean) -> Unit,
    ) {
        val row = layoutInflater.inflate(R.layout.row_switch, parent, false) as MaterialSwitch
        row.text = title
        row.isChecked = initial
        row.setOnCheckedChangeListener { _, checked -> onChange(checked) }
        parent.addView(row)
    }

    private fun addSlider(
        parent: LinearLayout,
        title: String,
        from: Int,
        to: Int,
        step: Int,
        initial: Int,
        format: (Int) -> String,
        onChange: (Int) -> Unit,
    ) {
        val row = layoutInflater.inflate(R.layout.row_slider, parent, false)
        val titleView = row.findViewById<TextView>(R.id.rowTitle)
        val valueView = row.findViewById<TextView>(R.id.rowValue)
        val slider = row.findViewById<Slider>(R.id.rowSlider)
        titleView.text = title
        slider.valueFrom = from.toFloat()
        slider.valueTo = to.toFloat()
        slider.stepSize = step.toFloat()
        val snapped = (((initial - from).toFloat() / step).roundToInt() * step + from).coerceIn(from, to)
        slider.value = snapped.toFloat()
        valueView.text = format(snapped)
        slider.addOnChangeListener { _, value, fromUser ->
            val v = value.roundToInt()
            valueView.text = format(v)
            if (fromUser) onChange(v)
        }
        parent.addView(row)
    }
}
